<?php
require_once (dirname(__DIR__) . '/commercereferralsreferrer.class.php');
class CommerceReferralsReferrer_mysql extends CommerceReferralsReferrer {}