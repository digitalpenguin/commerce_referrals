<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'MIT License

Copyright (c) 2018

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => 'Commerce_Referrals
------------------------

This Extra requires Commerce by Modmore.


This small module adds an extra page to the Commerce dashboard with a grid to keep partner company information.
Each partner is assigned a referral token which they can then use on the end of a product URL to send customers to your shop.

For example if a customer is assigned a token called `partnertoken`, they would add it on the end of your product URL with `?ref=partnertoken`.

As you can see here:
`https://example.com/shop/product/product.html?ref=partnertoken`

When a customer is referred to a product in your shop and adds that product to the shopping cart, the module will check if a partner exists for
that token. If so, the token is added to the order.

The manager user can then see if this is a referral order. A referral section is added to the order detail page in Commerce.
The partner company information is displayed so they can take whatever action they\'ve agreed to.



Install
-------

- Install the package and then activate the module in the configuration tab of the Commerce dashboard.

Usage
-----

- In the Commerce dashboard, click on the Referrals tab and then select **Referrers** in the subnav.
- Add details of a partner company that will refer customers to your products.
- One of the details will be a \'token\'. The referrer then adds this token on the end of the URL and their referral will then be recorded.
',
    'changelog' => 'Commerce_Referrals 1.1.0-pl
---------------------------
Released on 2023-07-01

- MODX 3 and PHP 8 compatibility
- Update to new Commerce dispatcher class
- Improve grid queries
- Fix bootstrapping
- Switch to using inbuilt Commerce order fields with twig template rather than injecting an HTML section.

++ Commerce_Referrals 1.0.2-pl
++ Released on 05-04-2019
++++++++++++++++++++++++++
- Fixed compatibility issues with Commerce 1.0
- Added check to make sure an order exists before altering it.
- Added the new \'raw\' column property to make sure links are formed correctly. (Thanks to MarkH)

++ Commerce_Referrals 1.0.1-pl
++ Released on 29-05-2018
++++++++++++++++++++++++++
- Made some positioning changes on the order page to take advantage of a new feature in Commerce 0.11.0-pl
- Added a tab_position system setting which takes a number and will insert the referral tab in that position.
- Changed to using Commerce style getters and setters in some places to ensure future compatibility.
- Some code cleanup

++ Commerce_Referrals 1.0.0-pl
++ Released on 27-05-2018
++++++++++++++++++++++++++
- First release
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '79e987b24782a8beeb9973e8e3afc6eb',
      'native_key' => 'commerce_referrals',
      'filename' => 'modNamespace/9fa6d02d47703e990740f3b9f9c6f713.vehicle',
      'namespace' => 'commerce_referrals',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6ab0cba57fd81ea73c1272790bdd3ac1',
      'native_key' => 'commerce_referrals.commerce_referrals.tab_position',
      'filename' => 'modSystemSetting/c40c050db6bdf89f9eaee3fb2795d3f0.vehicle',
      'namespace' => 'commerce_referrals',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '052cbd086eadab4e3eb1e3869ca1b2ac',
      'native_key' => 'commerce_referrals.commerce_referrals.assets_path',
      'filename' => 'modSystemSetting/7f7f6c9c8aa832509f41ce6880b1cfe7.vehicle',
      'namespace' => 'commerce_referrals',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3ecf544e1bf31587d1efd5d4facc5723',
      'native_key' => 'commerce_referrals.commerce_referrals.assets_url',
      'filename' => 'modSystemSetting/8f5adcade0e1792e2eb5cb13a894f5ae.vehicle',
      'namespace' => 'commerce_referrals',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce03c0698d45784376f0b9afd455e1a9',
      'native_key' => 'commerce_referrals.commerce_referrals.core_path',
      'filename' => 'modSystemSetting/ca01bd11638034fac73d6af59e259eaa.vehicle',
      'namespace' => 'commerce_referrals',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '1da92320075690ff10dd1e4cc61dd511',
      'native_key' => 1,
      'filename' => 'modPlugin/7786217c13b41cd16dd612b7b24840ca.vehicle',
      'namespace' => 'commerce_referrals',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '65c916c390fbb74010df41d4169dc154',
      'native_key' => 1,
      'filename' => 'modCategory/e52ce9bb8f8929d2fb76dd191540d72c.vehicle',
      'namespace' => 'commerce_referrals',
    ),
  ),
);