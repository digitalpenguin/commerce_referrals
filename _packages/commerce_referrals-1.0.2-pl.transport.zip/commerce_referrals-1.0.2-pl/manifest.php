<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'MIT License

Copyright (c) 2018

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => 'Commerce_Referrals
------------------------

This Extra requires Commerce by Modmore.


This small module adds an extra page to the Commerce dashboard with a grid to keep partner company information.
Each partner is assigned a referral token which they can then use on the end of a product URL to send customers to your shop.

For example if a customer is assigned a token called `partnertoken`, they would add it on the end of your product URL with `?ref=partnertoken`.

As you can see here:
`https://example.com/shop/product/product.html?ref=partnertoken`

When a customer is referred to a product in your shop and adds that product to the shopping cart, the module will check if a partner exists for
that token. If so, the token is added to the order.

The manager user can then see if this is a referral order. A referral section is added to the order detail page in Commerce.
The partner company information is displayed so they can take whatever action they\'ve agreed to.



Install
-------

- Install the package and then activate the module in the configuration tab of the Commerce dashboard.

Usage
-----

- In the Commerce dashboard, click on the Referrals tab and then select **Referrers** in the subnav.
- Add details of a partner company that will refer customers to your products.
- One of the details will be a \'token\'. The referrer then adds this token on the end of the URL and their referral will then be recorded.
',
    'changelog' => '++ Commerce_Referrals 1.0.2-pl
++ Released on 05-04-2019
++++++++++++++++++++++++++
- Fixed compatibility issues with Commerce 1.0
- Added check to make sure an order exists before altering it.
- Added the new \'raw\' column property to make sure links are formed correctly. (Thanks to MarkH)

++ Commerce_Referrals 1.0.1-pl
++ Released on 29-05-2018
++++++++++++++++++++++++++
- Made some positioning changes on the order page to take advantage of a new feature in Commerce 0.11.0-pl
- Added a tab_position system setting which takes a number and will insert the referral tab in that position.
- Changed to using Commerce style getters and setters in some places to ensure future compatibility.
- Some code cleanup

++ Commerce_Referrals 1.0.0-pl
++ Released on 27-05-2018
++++++++++++++++++++++++++
- First release
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'bb69c8948ed38037062c00bca419b3df',
      'native_key' => 'commerce_referrals',
      'filename' => 'modNamespace/04033eca62b0c7d0a2da91286477efe6.vehicle',
      'namespace' => 'commerce_referrals',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '26ba1975699a097613b50b97b72fa505',
      'native_key' => 'commerce_referrals.commerce_referrals.tab_position',
      'filename' => 'modSystemSetting/2a9837ff71f06590163630750aaab641.vehicle',
      'namespace' => 'commerce_referrals',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '733713dae1513cbbe3acbdf026d4328e',
      'native_key' => 'commerce_referrals.commerce_referrals.assets_path',
      'filename' => 'modSystemSetting/ed6394263f0eacc55a260eed1af01160.vehicle',
      'namespace' => 'commerce_referrals',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ff1b0eeb13fb96be925701f1a13aa0f9',
      'native_key' => 'commerce_referrals.commerce_referrals.assets_url',
      'filename' => 'modSystemSetting/cfc15306d4dc66cbc0c1f727242ad13c.vehicle',
      'namespace' => 'commerce_referrals',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a27cdf5b25996ad2be5b55d21ad3ae86',
      'native_key' => 'commerce_referrals.commerce_referrals.core_path',
      'filename' => 'modSystemSetting/a38c8b6898365fd2b38ce0bfe092b89f.vehicle',
      'namespace' => 'commerce_referrals',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => 'bb46db87a7f4e963138435ff5dff3d22',
      'native_key' => 1,
      'filename' => 'modPlugin/185724b73b2f56ed8bd1c85c55f43fc3.vehicle',
      'namespace' => 'commerce_referrals',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '188b11884f908e6849602ec4d9b5b812',
      'native_key' => 1,
      'filename' => 'modCategory/085e44b92b2e64528d650ff2c7d8399b.vehicle',
      'namespace' => 'commerce_referrals',
    ),
  ),
);