<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'MIT License

Copyright (c) 2018

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => 'Commerce_Referrals
------------------------

This Extra requires Commerce by Modmore.


This small module adds an extra page to the Commerce dashboard with a grid to keep partner company information.
Each partner is assigned a referral token which they can then use on the end of a product URL to send customers to your shop.

For example if a customer is assigned a token called `partnertoken`, they would add it on the end of your product URL with `?ref=partnertoken`.

As you can see here:
`https://example.com/shop/product/product.html?ref=partnertoken`

When a customer is referred to a product in your shop and adds that product to the shopping cart, the module will check if a partner exists for
that token. If so, the token is added to the order.

The manager user can then see if this is a referral order. A referral section is added to the order detail page in Commerce.
The partner company information is displayed so they can take whatever action they\'ve agreed to.



Install
-------

- Install the package and then activate the module in the configuration tab of the Commerce dashboard.

Usage
-----

- In the Commerce dashboard, click on the Referrals tab and then select **Referrers** in the subnav.
- Add details of a partner company that will refer customers to your products.
- One of the details will be a \'token\'. The referrer then adds this token on the end of the URL and their referral will then be recorded.
',
    'changelog' => '++ Commerce_Referrals 1.0.1-pl
++ Released on 29-05-2018
++++++++++++++++++++++++++
- Made some positioning changes on the order page to take advantage of a new feature in Commerce 0.11.0-pl
- Added a tab_position system setting which takes a number and will insert the referral tab in that position.
- Changed to using Commerce style getters and setters in some places to ensure future compatibility.
- Some code cleanup

++ Commerce_Referrals 1.0.0-pl
++ Released on 27-05-2018
++++++++++++++++++++++++++
- First release
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '9071003a9e2f932552a8de62247daed1',
      'native_key' => 'commerce_referrals',
      'filename' => 'modNamespace/14a91df769661dd237139743f71f9744.vehicle',
      'namespace' => 'commerce_referrals',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd176cfa439016f67baa6eb652b0c1180',
      'native_key' => 'commerce_referrals.commerce_referrals.tab_position',
      'filename' => 'modSystemSetting/be19235f070a9cd4182ee04bd3d7c929.vehicle',
      'namespace' => 'commerce_referrals',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e8ed031eb5bf5e50dd0a7bad7bd802a0',
      'native_key' => 'commerce_referrals.commerce_referrals.assets_path',
      'filename' => 'modSystemSetting/92c8d6d867b0ec6644281a21523efa97.vehicle',
      'namespace' => 'commerce_referrals',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e7eec36a8a1fbe6320e59883d38d8bb6',
      'native_key' => 'commerce_referrals.commerce_referrals.assets_url',
      'filename' => 'modSystemSetting/8a8e8dfc57abdbe8185e0448f7c5e27f.vehicle',
      'namespace' => 'commerce_referrals',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3796356b3ad2c7537754450afd8e8bc4',
      'native_key' => 'commerce_referrals.commerce_referrals.core_path',
      'filename' => 'modSystemSetting/869601365c03dc70784dd2fe7c68064d.vehicle',
      'namespace' => 'commerce_referrals',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '8166a3c8ce2e24f5e5a71a678cd40d96',
      'native_key' => 1,
      'filename' => 'modPlugin/5b7bf57215a0f16eb21b64032f834ba7.vehicle',
      'namespace' => 'commerce_referrals',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '08723178b6712d70cc352f87df84b030',
      'native_key' => 1,
      'filename' => 'modCategory/bda7e96c6987d8b5d9a85ea51db98da4.vehicle',
      'namespace' => 'commerce_referrals',
    ),
  ),
);