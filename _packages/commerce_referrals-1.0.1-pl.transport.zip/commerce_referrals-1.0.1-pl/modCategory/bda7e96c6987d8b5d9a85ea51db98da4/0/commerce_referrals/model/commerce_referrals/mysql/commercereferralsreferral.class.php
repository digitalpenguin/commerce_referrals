<?php
require_once (dirname(__DIR__) . '/commercereferralsreferral.class.php');
class CommerceReferralsReferral_mysql extends CommerceReferralsReferral {}