<?php
/**
 * Referrals for Commerce.
 *
 * Copyright 2018 by Your Name <your@email.com>
 *
 * This file is meant to be used with Commerce by modmore. A valid Commerce license is required.
 *
 * @package commerce_referrals
 * @license See core/components/commerce_referrals/docs/license.txt
 */
class CommerceReferralsReferrer extends comSimpleObject
{

}
