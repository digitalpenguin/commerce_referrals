<?php

$xpdo_meta_map = array (
  'comSimpleObject' => 
  array (
    0 => 'CommerceReferralsReferrer',
    1 => 'CommerceReferralsReferral',
  ),
);