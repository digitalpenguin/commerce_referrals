<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'MIT License

Copyright (c) 2018

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => 'Commerce_Referrals
------------------------

This Extra requires Commerce by Modmore.


This small module adds an extra page to the Commerce dashboard with a grid to keep partner company information.
Each partner is assigned a referral token which they can then use on the end of a product URL to send customers to your shop.

For example if a customer is assigned a token called `partnertoken`, they would add it on the end of your product URL with `?ref=partnertoken`.

As you can see here:
`https://example.com/shop/product/product.html?ref=partnertoken`

When a customer is referred to a product in your shop and adds that product to the shopping cart, the module will check if a partner exists for
that token. If so, the token is added to the order.

The manager user can then see if this is a referral order. A referral section is added to the order detail page in Commerce.
The partner company information is displayed so they can take whatever action they\'ve agreed to.



Install
-------

- Install the package and then activate the module in the configuration tab of the Commerce dashboard.

Usage
-----

- In the Commerce dashboard, click on the Referrals tab and then select **Referrers** in the subnav.
- Add details of a partner company that will refer customers to your products.
- One of the details will be a \'token\'. The referrer then adds this token on the end of the URL and their referral will then be recorded.
',
    'changelog' => '++ Referrals for Commerce 1.0.0-pl
++ Released on
++++++++++++++++++++++++++
- First release
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '0a9c2d4cd0ec82501c61e15879c69130',
      'native_key' => 'commerce_referrals',
      'filename' => 'modNamespace/543a0f8b22f1cd0c59813f7e44a48feb.vehicle',
      'namespace' => 'commerce_referrals',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5b799d53f10b2e0bd73f6ae2caec8e2f',
      'native_key' => 'commerce_referrals.commerce_referrals.assets_path',
      'filename' => 'modSystemSetting/a10f0caaab56217a2b6b601c4ef74683.vehicle',
      'namespace' => 'commerce_referrals',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a19870495e32de9e0c17d01365efe0fe',
      'native_key' => 'commerce_referrals.commerce_referrals.assets_url',
      'filename' => 'modSystemSetting/e8b4311710628b0193bf4fb85d1e61d2.vehicle',
      'namespace' => 'commerce_referrals',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '81d91bff61a4dab97a575037b4ef64d7',
      'native_key' => 'commerce_referrals.commerce_referrals.core_path',
      'filename' => 'modSystemSetting/3b81f9c36ebb3d62202b1e04bf2819dc.vehicle',
      'namespace' => 'commerce_referrals',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '0a0658c9fbcc8369ac2014699ba069d0',
      'native_key' => 1,
      'filename' => 'modPlugin/81a5f4ad5754ba273e40af50c33ac66f.vehicle',
      'namespace' => 'commerce_referrals',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'd957b881579677de71db46cc77a4c6a0',
      'native_key' => 1,
      'filename' => 'modCategory/6b91b87333af81acb63a4e7f887ad523.vehicle',
      'namespace' => 'commerce_referrals',
    ),
  ),
);